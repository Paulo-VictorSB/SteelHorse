<?php

defined('CONTROL') or die('Acesso negado!');

return [
    '404',
    'login',
    'register',
    'home'
];