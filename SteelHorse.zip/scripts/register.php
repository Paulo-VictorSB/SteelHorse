<?php defined('CONTROL') or die('Acesso negado!');

if($_SERVER['REQUEST_METHOD'] === 'POST')
{   
    $email = $_POST['email'];
    $nome = $_POST['nome'];
    $senha = $_POST['senha'];

    if (strlen($nome) < 5) 
    {
        echo "O nome deve ter pelo menos 5 caracteres.";
        exit;
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) 
    {
        echo "O email deve ser válido.";
        exit;
    }

    $senhaHash = password_hash($senha, PASSWORD_DEFAULT);

    $steelhorse_server = new user();
    $isValidRegister = $steelhorse_server->register($email, $nome, $senhaHash);
    header("Location: ?route=login");
}

?>

<div class="login-card">
    <h2 class="text-center mb-4">Registrar</h2>
    <form method="POST">
    <div class="mb-3">
            <label for="user" class="form-label">Usuário</label>
            <input type="text" class="form-control" id="user" placeholder="Digite seu usuário" name="nome">
            <!-- <small class="form-text">O Usuário já está em uso.</small> -->
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" placeholder="Digite seu email" name="email">
            <!-- <small class="form-text">O Email já está em uso.</small> -->
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Senha</label>
            <input type="password" class="form-control" id="password" placeholder="Digite sua senha" name="senha">
        </div>
        <div class="d-grid">
            <button type="submit" class="btn btn-primary">Registrar</button>
        </div>
        <div class="text-center mt-3">
            <small class="form-text">Já possuo uma conta. <a href="?route=login">Logar</a></small>
        </div>
    </form>
</div>