<?php 

defined('CONTROL') or die('Acesso negado!');

if($_SESSION['isLogged'] === false){
    header("Location: ?route=login");
    exit();
}

?>

<h1>Bem vindo! - <?=$_SESSION['nome']?></h1>