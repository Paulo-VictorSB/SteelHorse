<?php defined('CONTROL') or die('Acesso negado!');?>

<div>
    <h1>404</h1>
    <p>Página Não Encontrada</p>
    <a href="?route=home" class="btn btn-primary">Voltar para a Página Inicial</a>
</div>